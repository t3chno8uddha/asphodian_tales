---
Full_Name: Kahamag
Type: Locale
Location: "[[Asphodel's Arena]]"
Allegiance:
Opposition:
Populace:
Status: Standing
First_Seen: 
Tags:
marker: [{ coordinates: "2235, 5169", colour: "#73675f" }]
---
A trading town near center of Asphodel's Arena. The smallest, but the wealthiest considering in relativity to the other regions in the Arena.

![[Kahamag.png]]