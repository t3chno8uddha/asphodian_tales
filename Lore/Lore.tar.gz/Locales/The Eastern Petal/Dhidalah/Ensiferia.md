---
Full_Name: Ensiferia
Type: Locale
Location: "[[The Duchy of Dhidalah]]"
Allegiance:
Opposition:
Populace:
Status: Standing
First_Seen:
Tags:
marker: [{ coordinates: "2919, 4704", colour: "#69676b" }]
---
Ancient abandoned monastery.
1400 onward, a large oracle settlement south of Dhidalah.
Home to Alastor.