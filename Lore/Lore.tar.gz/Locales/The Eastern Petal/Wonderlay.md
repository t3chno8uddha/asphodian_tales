---
Full_Name: Wonderlay - The Radiant City
Type: Locale
Location: The Eastern Petal
Allegiance:
  - "[[Cronika]]"
  - "[[Lancast]]"
  - "[[Fidico]]"
Opposition:
  - "[[Drakengard]]"
Populace:
  - Gail
Status: Standing
First_Seen: 
Tags:
marker: [{ coordinates: "2220, 3759", colour: "#4a4a5c" }]
---
A kingdom held jointly by Cronika, Lancast and Fidico, rendered on the map as a gleaming "Radiant City" above the abyss. Theological and political friction between Wonderlay and **[[Drakengard]]** is what ignited Cronika's fatal **1400** attack on Draca.

Wonderlay, despite being considered a holy kingdom, is very profoundly corrupt. The same corruption led to Sir Francis fleeing it in 1413. 

It is important to note that Francis is the legitimate heir to the throne, despite him not knowing so.

![[Wonderlay_1.png]]
![[Wonderlay_2.png]]