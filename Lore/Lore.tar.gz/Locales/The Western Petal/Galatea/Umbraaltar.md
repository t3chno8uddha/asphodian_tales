---
Full_Name: Umbraaltar
Type: Shrine
Location: "[[The Great Lands of Galatea]]"
Allegiance:
  - "[[Temeran]]"
Opposition:
Populace:
Status: Standing
First_Seen: 1413
Tags:
marker: [{ coordinates: "2079, 2301", colour: "#585042" }]
---
A small shrine to Temeran.
In 1413, it held two items: the **New Moon Amulet** that lets the bearer travel through shadows, and a **Thundergale Fang**.
![[Umbraaltar.png]]
