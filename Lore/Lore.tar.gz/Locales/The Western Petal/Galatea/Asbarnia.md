---
Full_Name: Asbarnia
Type: Locale
Location: "[[The Great Lands of Galatea]]"
Allegiance:
Opposition:
Populace:
  - Gail
  - Aél
  - Undine
Status: Destroyed
First_Seen: 1413
Tags:
marker: [{ coordinates: "2259, 2445", colour: "#564441" }]
---
A lush, invigorating river-town: flourishing greenery over stone and wood, a curling river split into veins, gondolas drifting like feathers. A peaceful, mixed populace — Gail, Aél, even Undine by the gondolas; "no hatred in anyone's eyes." A far cry from the grimmer places around it.

Gate to [[The Archlibrary]].

Also home of Bishop **Clairmont**, who conducted the **Bell-Bearer ritual** through his painting collection in 1413. Clairmont sold the citizens' souls to [[Rafael]], and [[Duke Daedalus]] punished him by misleading him into burning his own village - and himself - to the ground.

![[Asbarnia.png]]
![[map_asbarnia.png]]