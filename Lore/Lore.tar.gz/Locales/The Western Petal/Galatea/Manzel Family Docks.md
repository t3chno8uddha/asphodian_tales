---
Full_Name: Manzel Family Docks
Type: Locale
Location: "[[The Great Lands of Galatea]]"
Allegiance:
  - "[[The Great Lands of Galatea]]"
Opposition:
Populace:
  - Aél
  - Gail
  - Biota
  - Undine
Status: Standing
First_Seen:
Tags:
  - Port
marker: [{ coordinates: "2151, 1872", colour: "#5c4e54" }]
---
A small port village south of [[Papillopolis - The First Forest]].

![[Manzel_Family_Docks.png]]
