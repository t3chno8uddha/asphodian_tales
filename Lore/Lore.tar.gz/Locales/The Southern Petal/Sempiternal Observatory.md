---
Full_Name: The Sempiternal Observatory
Type: Shrine
Location: "[[The Undone Empire Kronitia]]"
Allegiance:
  - "[[Cronika]]"
Opposition:
Populace:
Status: Standing
First_Seen:
Tags:
marker: [{ coordinates: "1419, 3354", colour: "#67656c" }]
---
A place where one can view time throughout history, and its many branches.

![[The_Sempiternal_Observatory.png]]
