---
Full_Name: High General Perialus
Type: NPC
Heritage:
Birthplace: "[[The Great Lands of Galatea]]"
Location: "[[Mansfield Manor]]"
Allegiance:
Opposition:
Family:
Status: Dead
First_Seen: 1413
Tags:
---
Ruler of Mansfield Manor in 1413, before his undoing and the freeing of all magical prisoners held inside the stronghold's walls.
![[High_General_Perialus.png]]