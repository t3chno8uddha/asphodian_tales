---
Full_Name: Cornelius
Type: NPC
Heritage:
Birthplace: "[[The Great Lands of Galatea]]"
Location: "[[The Great Lands of Galatea]]"
Allegiance:
  - "[[Rafael]]"
Opposition:
  - "[[Graphel]]"
  - "[[Hemos]]"
  - "[[Sigurd]]"
  - "[[Araspeth]]"
  - "[[Francis]]"
  - "[[Chiriani]]"
Family:
Status: Vague
First_Seen: 1413
Tags:
---
The leading Galatean witch-hunter general. In 1413, brainwashed by Rafael to slowly make his way up and control Galatea from within, segregating its magical and human residents. He kidnapped the princess and tried to take over the kingdom, before being taken down by [[Graphel]], [[Hemos]], [[Sigurd]], [[Araspeth]], [[Francis]] and [[Chiriani]].