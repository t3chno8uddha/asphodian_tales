---
Full_Name: Theo
Type: NPC
Heritage: Aél
Birthplace: "[[The Great Lands of Galatea]]"
Location: "[[Eethert Plains]]"
Allegiance:
  - "[[The Great Lands of Galatea]]"
  - "[[Francis]]"
  - "[[Graphel]]"
  - "[[Abara]]"
Opposition:
Family:
Status: Alive
First_Seen: 1413
Tags:
---
A short Aél who travelled with the party in 1413, leaving before Asbarnia.