---
Full_Name: Princess Melodia
Type: NPC
Heritage:
Birthplace: "[[The Great Lands of Galatea]]"
Location: "[[The Great Lands of Galatea]]"
Allegiance:
  - "[[The Great Lands of Galatea]]"
  - "[[Rafael]]"
  - "[[Graphel]]"
Opposition:
Family:
  - "[[Hemos]]"
Status: Alive
First_Seen: 1413
Tags:
---
Princess of Galatea, sister of prince Hemos, and a friend of Graphel. As of 1441, brainwashed by Rafael.