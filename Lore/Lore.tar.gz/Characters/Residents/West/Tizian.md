---
Full_Name: Tizian Tarrin
Type: NPC
Heritage:
Birthplace: "[[Mansfield Manor]]"
Location: "[[Mansfield Manor]]"
Allegiance:
  - "[[Rafael]]"
Opposition:
Family:
Status: Alive
First_Seen: 1441
Tags:
---
The minister of Treasury of Mansfield. Under Rafael's employ and control.
![[Tizian_Tarrin.png]]