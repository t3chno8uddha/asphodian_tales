---
Full_Name: Rafael Tannengard
Type: NPC
Heritage: Gail
Birthplace: "[[The Undone Empire Kronitia]]"
Location: "[[The Great Lands of Galatea]]"
Allegiance:
  - "[[Cronika]]"
Opposition:
  - "[[Raul]]"
  - "[[Draca]]"
  - "[[Drakengard]]"
  - "[[The Duchy of Dhidalah]]"
  - "[[Duke Daedalus]]"
Family:
  - "[[Raul]]"
  - "[[Diya]]"
Status: Alive
First_Seen: 1413
Tags:
  - Godblood
  - Chronopath
---
A chronopath of the Holy Kronitian Empire - raised in a noble and erudite family, a direct descendant of Cronika and [[Galatus]]' daughter Diya, and beyond Death's reach in 1400.
After Cronika's death, Rafael wanted to see [[Draca]] and her worshipers dead. He fought his brother Raul, won, and sent his body parts flying across the world. By Raul's foggy account, it was Rafael himself who destroyed the Empire.
In 1413: he brainwashed the witch-hunter [[Cornelius]] to control Galatea from within; employed [[Magnus]] and [[Lillianele]] to break [[Oleander Gaust]] out of [[Infernait]] to hunt down [[Francis]]; bought the souls of [[Asbarnia]]'s citizens from [[Bishop Clairmont]]; and brought [[Maxill]] back to life as a Calx, becoming his master. Tracing Raul to the destruction of Mansfield, he attacked him at sea, defeated him again, and trapped his soul, hiding it away where no one would find it.
By 1441, Rafael had hypnotized and manipulated his way into the Galatean throne-room, seeking to wage war against Dhidalah, Draca, her kingdom Drakengard and all of her worshipers, to avenge his empire. That same year, he attacked [[Wassonia]] with his Abyssal army in search of an ancient tome written in Godspeak, claiming a torn half of it.

![[Rafael.png]]
