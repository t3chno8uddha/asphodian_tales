---
Full_Name: Elymas
Type: NPC
Heritage: Gail
Birthplace: "[[Mansfield Manor]]"
Location: "[[Castle Kingdom Magnolia]]"
Allegiance:
Opposition:
Family:
Status: Alive
First_Seen: 1441
Tags:
---
A champion prepared for the Idolon Arena of Castle Kingdom Magnolia, with access to **all** Knight, Hunter and Drifter abilities.
![[Elymas.png]]