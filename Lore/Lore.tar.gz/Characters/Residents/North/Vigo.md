---
Full_Name: Vigo
Type: NPC
Heritage: Aél
Birthplace:
Location: "[[Brejur Academy]]"
Allegiance:
  - "[[Alastor]]"
Opposition:
Family:
Status: Alive
First_Seen: 1441
Tags:
  - Abyss_Mastery
---
A child student of Brejur Academy, with no real grasp of his power. Vigo unknowingly Abyssal Mastered the academy's entire population while he played the piano. Threatened, he can turn the population into the Manipede, a massive magical human worm
Currently being tutored in Magnolia.
![[Vigo.png]]