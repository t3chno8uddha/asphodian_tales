---
Full_Name: Ettrick
Type: NPC
Heritage:
Birthplace: "[[Manzel Family Docks]]"
Location: "[[Heathen Homestead]]"
Allegiance:
  - The Highest Bidder
  - "[[Rafael]]"
Opposition:
Family:
Status: Alive
First_Seen:
Tags:
---
A travelling merchant in the employ of Rafael. Enlisted Juanush, Sani, Marine, Caliburn and Via to ship corpses to Mansfield.
![[Ettrick.png]]