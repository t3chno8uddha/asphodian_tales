---
Full_Name: King Robert IV
Type: NPC
Heritage: Gail
Birthplace: "[[Wonderlay]]"
Location:
Allegiance:
  - "[[Wonderlay]]"
Opposition:
Family:
  - "[[Francis]]"
Status: Dead
First_Seen: 1413
Tags:
---
An old king, appearing in Sir Francis's Papillopolis vision of 1413 - watching the trials from a tree stump, greeting Francis as son, and telling him the tree deemed his trial unnecessary.
![[King_Robert_IV.png]]