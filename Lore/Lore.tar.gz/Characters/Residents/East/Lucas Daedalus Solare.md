---
Full_Name: Lucas Daedalus Solare
Type: NPC
Heritage: Vampyr
Birthplace:
Location: "[[Castle Kingdom Magnolia]]"
Allegiance:
  - "[[Duke Daedalus]]"
Opposition:
Family:
  - "[[Hemos]]"
  - "[[Duke Daedalus]]"
Status: Alive
First_Seen: 1441
Tags:
  - Godblood
---
Son of Hemos Solare, and grandson of Duke Daedalus. In 1441, he faced [[Graphel]] at the Idolon Arena tournament of Castle Kingdom Magnolia.
![[Lucas_Daedalus_Solare.png]]