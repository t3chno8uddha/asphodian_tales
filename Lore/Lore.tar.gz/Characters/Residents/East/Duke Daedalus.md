---
Full_Name: Duke Aurus Daedalus
Type: NPC
Heritage: Vampyr
Birthplace: "[[The Duchy of Dhidalah]]"
Location: "[[The Duchy of Dhidalah]]"
Allegiance:
  - "[[Draca]]"
  - "[[Temeran]]"
  - "[[Cronika]]"
Opposition:
  - "[[Rafael]]"
Family:
  - "[[Draca]]"
  - "[[Temeran]]"
  - "[[Hemos]]"
  - "[[Lucas Daedalus Solare]]"
  - "[[Second Son]]"
Status: Alive
First_Seen: 1441
Tags:
  - Godblood
---
Son of Draca and Temeran, the ruler of The Duchy of Dhidalah, the first Vampyr, and the father of all Vampyr.

Though Draca's own descendant, **Daedalus** views Cronika's death (1400) as a senseless tragedy and is searching for Cronika's surviving godbloods - Raul, Rafael, Graphel - to transform them back into Cronika, restoring the status quo.

In 1441, he invited the caravan to his kingdom for a seance, intending to convince them to hunt the Tannengards and willingly sacrifice Graphel for the ritual.

In case of rejection, he will agree to let them go peacefully and not directly interfere until the remaining two are in his grasp.
![[Duke_Daedalus.png]]