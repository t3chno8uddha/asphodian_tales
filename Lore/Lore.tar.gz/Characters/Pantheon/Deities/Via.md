---
Full_Name: Via
Type: Deity
Birthplace: "[[Papillopolis - The First Forest]]"
Location: "[[Dunacces]]"
Allegiance:
  - "[[Lutrios]]"
Opposition:
Family:
  - "[[Joy]]"
  - "[[Lutrios]]"
Status: Alive
First_Seen: 1441
Tags:
  - Empyrean
---
The sister of Joy, and the avatar of wind. This Spectral maiden travels the world in search for entertainment.

AS of 1441, an occurance beyond her understanding had erased her memories, and she joined [[Caliburn]] in his travels.
![[via.png]]