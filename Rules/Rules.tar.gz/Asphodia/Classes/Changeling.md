---
quartz-properties: false
unlisted: true
tags:
  - rules
  - rules/asphodia
  - rules/class
---
- **Ethereal Matter** -{**P**}- Turn briefly to mist - swift and elusive - and you may carry an element within you to harm what you pass through.
- **Devil's Minion** -{**P**}- Your held possessions never slip or break, and you may move them by will within reach.
- **Shapeshift** -{**A**}-{**Arcane**}- Take the shape of another creature, up to your own size; the greater the change, the more it may strain you.
- **Telepathy** -{**A**}-{**Mental**}- Reach into a mind to read its thoughts and speak within it; with strain, you may plant or rewrite what you find there.
- **Doppelganger** -{**S**}-{**Arcane**}- Temporarily summon an identical double of yourself that can act and wield your abilities; with fresh blood, you may instead copy another. The doppelganger acts with its own agency. ``