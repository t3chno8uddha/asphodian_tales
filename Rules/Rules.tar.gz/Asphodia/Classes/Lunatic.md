---
quartz-properties: false
unlisted: true
tags:
  - rules
  - rules/asphodia
  - rules/class
---
- **Devil Whisperer** -{**P**}- You can converse with Abyssals; +1♦ when dealing with them.
- **Hell's Kitchen** -{**A**}-{**Physical**}- Devour flesh, blood, and bone to heal and regrow lost limbs; what you eat, you may come to remember, and what you eat, you may temporarily become.
- **Chimerism** -{**A**}-{**Physical**}- Ingest the parts of beasts, men, or Abyssals to later graft their limbs and features onto yourself.
- **Altered Beast** -{**S**}-{**Arcane**}- Morph into your Abyssal form: your body grows mightier as your mind frays, and you must hold yourself together to act with reason.
- **To Hell in a Hand-basket** -{**S**}-{**Arcane**}- Step your spirit - or your whole body - into the Umbral Plane where Abyssals dwell, and carry others with you.